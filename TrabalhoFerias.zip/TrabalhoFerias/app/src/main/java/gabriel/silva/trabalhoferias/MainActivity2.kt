package gabriel.silva.trabalhoferias

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity2 : AppCompatActivity() {

    private lateinit var buttonOpenActivity : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val actionBar = supportActionBar

        actionBar?.let {
            it.setDisplayHomeAsUpEnabled(true)
            it.title = "Tela 2"
        }

        override fun onSupportNavigateUp(): Boolean {
            onBackPressed()
            return true
        }

        initizalizer()

        buttonOpenActivity.setOnClickListener {

            val intent = Intent(this@MainActivity, MainActivity2::class.java)
            startActivity(intent)

        }
    }

    private fun initizalizer() {
        buttonOpenActivity = findViewById(R.id.buttonOpenNewActivity)
    }
}

class MainActivity2 : AppCompatActivity() {

    private lateinit var buttonOpenActivity: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_MainActivity2)

        initializer()

        buttonOpenActivity.setOnClickListener {

            val intent = Intent(this@MainActivity2, MainActivity3::class.java)
            startActivity(intent)
        }

    }

    private fun initializer() {
        buttonOpenActivity = findViewById(R.id.buttonMainActivity3)
    }



}