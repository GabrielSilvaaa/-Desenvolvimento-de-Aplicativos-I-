package gabriel.silva.trabalhoferias

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main3.*

class MainActivity3 : AppCompatActivity() {

    private lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        initializer()

        mediaPlayer = MediaPlayer.create(this@MainActivity3, R.raw.batida)
        mediaPlayer.start()
        play(R.raw.batida)

    }

    override fun onStop() {
        stop()
        super.onStop()
    }

    private fun initializer() {
        buttonBeat = findViewById(R.id.buttonBeat)
    }

    private fun play(sound: Int) {
        mediaPlayer = MediaPlayer.create(this@MainActivity3, R.raw.batida)
        mediaPlayer.start()
    }

    private fun stop() {
        if(mediaPlayer.isPlaying) {
            mediaPlayer.stop()
    }
}