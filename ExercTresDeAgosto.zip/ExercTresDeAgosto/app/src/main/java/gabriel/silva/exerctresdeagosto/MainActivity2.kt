package gabriel.silva.exerctresdeagosto

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class activity_main2.xml : AppCompatActivity() {

    private val TAG_LOG_MAIN_ACTIVITY: String = "TagMainActivity"
    private lateinit var editTextURL : EditText
    private lateinit var buttonBrowser : Button
    private lateinit var editTextPhone : EditText
    private lateinit var buttonDial : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.MainActivity2)
        Log.d(TAG_LOG_MAIN_ACTIVITY, "Entrou no onCreate")

        initializer()

        val valueEmail = intent.getStringExtra("valueEmail")

        Toast.makeText(baseContext, "${getString(R.string.welcome)}$valueEmail!",Toast.LENGTH_LONG).show()

        buttonBrowser.setOnClickListener {
            val URL = editTextURL.text.toString()
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://${URL}"))
            startActivity(intent)
        }

        buttonDial.setOnClickListener {
            val URL = editTextPhone.text.toString()
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("(+51)${URL}"))
            startActivity(intent)
        }

    }

    private fun initializer() {
        editTextURL = findViewById(R.id.editTextURL)
        buttonBrowser = findViewById(R.id.buttonBrowser)
        editTextPhone = findViewById(R.id.editTextPhone)
        buttonDial = findViewById(R.id.buttonDial)
    }
}