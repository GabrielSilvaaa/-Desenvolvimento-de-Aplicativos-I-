package gabriel.silva.exemplokotlindiavinteum

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var editTextName1 : EditText
    private lateinit var editTextName2 : EditText
    private lateinit var buttonSeePercentage : Button
    private lateinit var textViewResponse : TextView

    override fun onCreate(savedInstanceState : Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextName1 = findViewById(R.id.editTextName1)
        editTextName2 = findViewById(R.id.editTextName2)
        buttonSeePercentage = findViewById(R.id.buttonSeePorcentage)
        textViewResponse = findViewById(R.id.textViewResponse)

        buttonSeePercentage.setOnLongClickListener {
            var name1 = editTextName1.text.toString()
            var name2 = editTextName2.text.toString().toInt()

            val random = (0..100).random()

            val response = "${getText(R.string.message_name1)}: $name1\n${getText(R.string.message_name2)}: $name2\n${getText(R.string.message_are_you)} $random % ${getText(R.string.message_beautiful)}"

            Toast.makeText(baseContext, response, Toast.LENGTH_LONG).show()

            textViewResponse.text = response

            clean()

        }
    }

    private fun clean(){
        editTextName1.text.clear()
        editTextName2.text.clear()
    }
}