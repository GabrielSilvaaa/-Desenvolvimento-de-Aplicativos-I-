package thiago.cury.exkotlin

import android.content.Context
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.view.*

class MainActivity : AppCompatActivity() {
    private lateinit var editTextName: EditText
    private lateinit var buttonVibrate: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initializar()
        buttonVibrate.setOnClickListener {
            vibrate()
            var name = editTextName.text.toString()
            val random = (0..100).random()
            var dayResponse = when (random) {
                in 0..60 -> "O dia está mais ou menos"
                in 61..100 -> "O dia está muito bonito"
                else -> "Não existe dia!"
            }
            Toast.makeText(baseContext, text: "$name. $dayResponse", Toast.LENGTH_LONG).show()
            clear()
        }
    }

    private fun clear() { editTextName.text.clear() }

    private fun initializar() {

        editTextName = findViewById(R.id.editTextName)
        buttonVibrate = findViewById(R.id.buttonVibrate)
    }

    private fun vibrate() {
        val pattern = longArrayOf(0, 200, 100, 300)

        val hardware = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

        hardware?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES .0) {
            hardware.vibrate(VibrationEffect.createWaveform(pattern, repeat: - 1))
        }
        }
    }
}
        buttonVibrate.setOnClickListener {
            var name = editTextName.text.toString().toInt()

            val random = (0..100).random()

            val response = "${"Name"}: $name\n${"Age"}: $age\n${getText(R.string.message_the_day_is)} $randow % ${"beautiful"}"

            Toast.makeText(baseContext, response, Toast.LENGTH_LONG).show()

            textViewResponse.text = response

            clean()

            buzzer?.let {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    buzzer.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else {
                    buzzer.vibrate(pattern, -1)
                }
            }

        }

    }

    private fun clean() {
        editTextName.text.clear()
        editTextAge.text.clear()
    }
}