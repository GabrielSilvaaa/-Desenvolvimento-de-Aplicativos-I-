package gabriel.silva.exercseisdeagosto

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main2.*

class MainActivity : AppCompatActivity() {

    private lateinit var radioGroupGender: RadioGroup
    private lateinit var radioButtonMale: Button
    private lateinit var radioButtonFemale: Button
    private lateinit var buttonChoose: Button
    private lateinit var textViewResponse: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializer()

        radioGroupGender.setOnCheckedChangeListener(
            RadioGroup.OnCheckedChangeListener { group, checkedId ->
                val radio: RadioButton = findViewById(checkedId)
                val person = Person(radio.text.toString())
                Toast.makeText(baseContext, person.toString(), Toast.LENGTH_LONG).show()
                textViewResponse.text = person.verifyGender()
            }
        )

        buttonChoose.setOnClickListener {

            if(radioGroupGender.checkedRadioButtonId != -1) {

                val radio: RadioButton = findViewById(radioGroupGender.checkedRadioButtonId)

                val radioButton: RadioButton? = findViewById(radioGroupGender.checkedRadioButtonId)
                val text = radioButton?.text ?: "Outros"

            } else {
                Toast.makeText(baseContext, "Choose a gender now!!!!", Toast.LENGTH_LONG).show()
            }
        }

    }

    private fun initializer() {
        radioGroupGender = findViewById(R.id.radioGroupGender)
        radioButtonMale = findViewById(R.id.radioButtonMale)
        radioButtonFemale = findViewById(R.id.radioButtonFemale)
        buttonChoose = findViewById(R.id.buttonChoose)

        textViewResponse = findViewById(R.id.textViewResponse)

    }
}