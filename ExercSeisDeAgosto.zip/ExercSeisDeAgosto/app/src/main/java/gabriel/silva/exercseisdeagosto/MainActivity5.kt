package gabriel.silva.exercseisdeagosto

import android.content.Context
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var editTextVibrate: EditText
    private lateinit var buttonVibrate: Button
    private lateinit var buttonNext: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initizalizer()

        buttonVibrate.setOnClickListener {

            var name = editTextName.text.toString()

            if(name.length < 2) {
                Toast.makeText(baseContext, getText(R.string.message_invalid_name), Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            val random = (0..100).random()

            var response = when(random) {
                in 0..40 -> getString(R.string.message_bad)
                in 41..70 -> getString(R.string.message_good)
                in 71..100 -> getString(R.string.message_great)
                else -> getString(R.string.message_invalid)
            }

            Toast.makeText(baseContext, "$name. ${getText(R.string.message_the_day_is)} $response", Toast.LENGTH_LONG).show()
            clear()
            vibrate()
        }
    }

    private fun vibrate() {

        val pattern = longArrayOf(0, 200, 100, 300)

        val hardware = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

        hardware?.let {
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                hardware.Vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                hardware.vibrate(pattern, -1)
            }
        }
    }

    private fun initizalizer() {

        editTextVibrate = findViewById(R.id.editTextVibrate)
        buttonVibrate = findViewById(R.id.buttonVibrate)
        buttonNext = findViewById(R.id.buttonNext)

    }

    private fun clear() {
        editTextName.text.clear()
    }
}

class MainActivity : AppCompatActivity() {

    private lateinit var buttonOpenActivity: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_MainActivity)

        initializer()

        buttonOpenActivity.setOnClickListener {

            val intent = Intent(this@MainActivity, MainActivity2::class.java)
            startActivity(intent)
        }

    }

    private fun initializer() {
        buttonOpenActivity = findViewById(R.id.buttonMainActivity3)
    }



}