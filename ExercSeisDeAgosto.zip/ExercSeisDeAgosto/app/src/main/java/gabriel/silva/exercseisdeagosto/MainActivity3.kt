package gabriel.silva.exercseisdeagosto

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast


class ActivitySpinner : AppCompatActivity() {

    private lateinit var spinnerGender: Spinner
    private lateinit var buttonChoose: Button

    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_spinner)

        initializer()

        buttonChoose.setOnClickListener {
            if(spinnerGender.selectedItemPosition != 0) {

                val person = Person(spinnerGender.selectedItem.toString())

                Toast.makeText(baseContext, person.toString(), Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(baseContext, "Choose a gender now!", Toast.LENGTH_LONG).show()
            }

        }

    }

    private fun initializer() {
        spinnerGender = findViewById(R.id.activitySpinnerGender)
        buttonChoose = findViewById(R.id.activitySpinnerButtonChoose)

        val listGender = arrayOf("Choose a gender", "Male", "Female")

        adapter = ArrayAdapter(
            this@ActivitySpinner,
            android.R.layout.simple_dropdown_item_1line,
            listGender)

        spinnerGender.adapter = adapter
    }
}