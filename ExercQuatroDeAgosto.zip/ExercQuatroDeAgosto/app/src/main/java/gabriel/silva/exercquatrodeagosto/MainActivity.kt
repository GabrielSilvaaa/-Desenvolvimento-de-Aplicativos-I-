package gabriel.silva.exercquatrodeagosto

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import java.io.Serializable
import gabriel.silva.exercquatrodeagosto.model.Client

class MainActivity : AppCompatActivity() {

    private lateinit var editTextName:EditText
    private lateinit var editTextPassword:EditText
    private lateinit var buttonNext: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializer()
        buttonNext.setOnClickListener {
            val intent= Intent(this@MainActivity,MainActivity2::class.java)
            startActivity(intent)
        }

        buttonNext.setOnClickListener {
            val Client=Client()
            Client.name = editTextName.text.toString()

            val intent=Intent(this@MainActivity, MainActivity2::class.java)
            intent.putExtra("Client", Client)
            startActivity(intent)
        }
    }

    private fun initializer(){
        editTextName:EditText = findViewById(R.id.editTextName)
        editTextPassword = findViewById(R.id.editTextPassword)
        buttonNext = findViewById(R.id.buttonNext)
    }
}