package gabriel.silva.exercquatrodeagosto

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ActivityCompat
import gabriel.silva.exercquatrodeagosto.model.Client
import java.util.jar.Manifest

class activity_main2.xml : AppCompatActivity() {

    private lateinit var editTextPhone: EditText
    private lateinit var buttonCall: Button

    private val CALL_PHONE_REQUEST_CODE: Int=1000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.MainActivity2)

        val client = intent.getSerializableExtra("client") as Client

        Toast.Text(baseContext, "Objeto:${client}",Toast.LENGTH_LONG).show()

        initializer()
        buttonCall.setOnClickListener {
            Call()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when(requestCode){
            CALL_PHONE_REQUEST_CODE -> {
                if (grantResults.isEmpty() || grantResults[0] != packageManager.PERMISSION_GRANTED){
                    Toast.Text(baseContext,"Ligação Encerrada",Toast.LENGTH_LONG).show()
                }else{
                    Call()
                }
            }
        }
    }

    private fun requestPermission(){
        ActivityCompat.requestPermissions(
            this@MainActivity2,
            arrayOf(Manifest.permisson.CALL_PHONE),
            CALL_PHONE_REQUEST_CODE)
    }

    private fun Call(){
        val phone=editTextPhone.toString()
        val intent=Intent(Intent.ACTION_CALL, Uri.parse("tel:$phone"))

        if (ActivityCompat.checkSelfPermission(this@MainActivity2, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED){
            startActivity(intent)
        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this@MainActivity2, Manifest.permission.CALL_PHONE)){
                Toast.makeText(baseContext, Toast.LENGTH_LONG).show()
            }
            requestPermission()
        }

    }

    private fun initializer(){
        editTextPhone=findViewById(R.id.editPhone)
        buttonCall=findViewById(R.id.buttonCall)
    }
}