package gabriel.silva.exercquatrodeagosto.model

import java.io.Serializable

class Client : Serializable {
    var name:String?=""

    override fun toString(): String {
        return " Good Afternoon $name "
    }

}