package gabriel.silva.exerciciotimes

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {

    private lateinit var buttonAlert: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        buttonAlert = findViewById(R.id.button111)
        buttonAlert.setOnLongClickListener(object : View.OnLongClickListener {
            override fun onLongClick(p0: View?): Boolean {
                var alert = Alert.Builder(this@MainActivity)
                alert.setMessage(getText(R.string.alert_message_gremio))
                alert.setTitle(getText(R.string.alert_title_gremio))
                alert.setNeutralButton(getText(R.string.alert_neutral_button_gremio), null)
                alert.show()
                return true
            }
        }}

        buttonAlert = findViewById(R.id.button11)
        buttonAlert.setOnLongClickListener(object : View.OnLongClickListener {
            override fun onLongClick(p0: View?): Boolean {
                var alert = Alert.Builder(this@MainActivity)
                alert.setMessage(getText(R.string.alert_message_corinthians))
                alert.setTitle(getText(R.string.alert_title_corinthians))
                alert.setNeutralButton(getText(R.string.alert_neutral_button_corinthians), null)
                alert.show()
                return true
            }
        }}

        buttonAlert = findViewById(R.id.button12)
        buttonAlert.setOnLongClickListener(object : View.OnLongClickListener {
            override fun onLongClick(p0: View?): Boolean {
                var alert = Alert.Builder(this@MainActivity)
                alert.setMessage(getText(R.string.alert_message_fluminense))
                alert.setTitle(getText(R.string.alert_title_fluminense))
                alert.setNeutralButton(getText(R.string.alert_neutral_button_fluminense), null)
                alert.show()
                return true
            }
        }}

        buttonAlert = findViewById(R.id.button13)
        buttonAlert.setOnLongClickListener(object : View.OnLongClickListener {
            override fun onLongClick(p0: View?): Boolean {
                var alert = Alert.Builder(this@MainActivity)
                alert.setMessage(getText(R.string.alert_message_flamengo))
                alert.setTitle(getText(R.string.alert_title_flamengo))
                alert.setNeutralButton(getText(R.string.alert_neutral_button_flamengo), null)
                alert.show()
                return true
            }
        }}

        buttonAlert = findViewById(R.id.button14)
        buttonAlert.setOnLongClickListener(object : View.OnLongClickListener {
            override fun onLongClick(p0: View?): Boolean {
                var alert = Alert.Builder(this@MainActivity)
                alert.setMessage(getText(R.string.alert_message_inter))
                alert.setTitle(getText(R.string.alert_title_inter))
                alert.setNeutralButton(getText(R.string.alert_neutral_button_inter), null)
                alert.show()
                return true
            }
        }}

        buttonAlert = findViewById(R.id.button15)
        buttonAlert.setOnLongClickListener(object : View.OnLongClickListener {
            override fun onLongClick(p0: View?): Boolean {
                var alert = Alert.Builder(this@MainActivity)
                alert.setMessage(getText(R.string.alert_message_sao_paulo))
                alert.setTitle(getText(R.string.alert_title_sao_paulo))
                alert.setNeutralButton(getText(R.string.alert_neutral_button_sao_paulo), null)
                alert.show()
                return true
            }
        }}

        buttonAlert = findViewById(R.id.button16)
        buttonAlert.setOnLongClickListener(object : View.OnLongClickListener {
            override fun onLongClick(p0: View?): Boolean {
                var alert = Alert.Builder(this@MainActivity)
                alert.setMessage(getText(R.string.alert_message_botafogo))
                alert.setTitle(getText(R.string.alert_title_botafogo))
                alert.setNeutralButton(getText(R.string.alert_neutral_button_botafogo), null)
                alert.show()
                return true
            }
        }}

        buttonAlert = findViewById(R.id.button17)
        buttonAlert.setOnLongClickListener(object : View.OnLongClickListener {
            override fun onLongClick(p0: View?): Boolean {
                var alert = Alert.Builder(this@MainActivity)
                alert.setMessage(getText(R.string.alert_message_santos))
                alert.setTitle(getText(R.string.alert_title_santos))
                alert.setNeutralButton(getText(R.string.alert_neutral_button_santos), null)
                alert.show()
                return true
            }
        }}
    }

        fun buttonGremio(view: View) {
            Toast.makeText(this@MainActivity, getText(R.string.toast_message_gremio), Toast.LENGTH_LONG).show()
        }

        fun buttonCorinthins(view: View) {
            Toast.makeText(this@MainActivity, getText(R.string.toast_message_corinthians), Toast.LENGTH_LONG).show()
        }

        fun buttonFluminense(view: View) {
            Toast.makeText(this@MainActivity, getText(R.string.toast_message_fluminense), Toast.LENGTH_LONG).show()
        }

        fun buttonFlamengo(view: View) {
            Toast.makeText(this@MainActivity, getText(R.string.toast_message_flamengo), Toast.LENGTH_LONG).show()
        }

        fun buttonInter(view: View) {
            Toast.makeText(this@MainActivity, getText(R.string.toast_message_inter), Toast.LENGTH_LONG).show()
        }

        fun buttonSaoPaulo(view: View) {
            Toast.makeText(this@MainActivity, getText(R.string.toast_message_sao_paulo), Toast.LENGTH_LONG).show()
        }

        fun buttonBotafogo(view: View) {
            Toast.makeText(this@MainActivity, getText(R.string.toast_message_botafogo), Toast.LENGTH_LONG).show()
        }

        fun buttonSantos(view: View) {
            Toast.makeText(this@MainActivity, getText(R.string.toast_message_santos), Toast.LENGTH_LONG).show()
        }
}